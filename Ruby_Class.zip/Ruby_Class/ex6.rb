types_of_people = 10
x = "There are #{types_of_people} types people."
binary = "binary"
do_not = "don't"
y = "Those who know #{binary} and those who #{do_not}."

# this starts the joke
puts x
puts y

# repeating the joke with the type of people
puts "I said: #{x}."
puts "I also said: '#{y}'."

# answers the question of the joke with false
hilarious = false
joke_evaluation = "Isn't that joke so funny?! #{hilarious}"

puts joke_evaluation 

w = "This is the left side of..."
e = "a string with a right side."
d = "nothing to see here."

puts w + e + d
